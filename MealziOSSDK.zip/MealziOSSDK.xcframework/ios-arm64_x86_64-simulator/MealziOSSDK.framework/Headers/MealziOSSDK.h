//
//  MealziOSSDK.h
//  MealziOSSDK
//
//  Created by Diarmuid McGonagle on 20/03/2024.
//

#import <Foundation/Foundation.h>

//! Project version number for MealzIOSFramework.
FOUNDATION_EXPORT double MealziOSSDKVersionNumber;

//! Project version string for MealzIOSFramework.
FOUNDATION_EXPORT const unsigned char MealziOSSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MealzIOSFramework/PublicHeader.h>


