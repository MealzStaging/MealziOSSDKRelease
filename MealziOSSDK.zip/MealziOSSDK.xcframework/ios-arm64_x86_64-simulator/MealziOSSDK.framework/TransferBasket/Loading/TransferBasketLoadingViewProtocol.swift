//
//  File.swift
//
//
//  Created by Damien Walerowicz on 08/07/2024.
//

import Foundation
import SwiftUI

@available(iOS 14, *)
public protocol TransferBasketLoadingViewProtocol {
    associatedtype Content: View
    func content(params: TransferBasketLoadingViewParameters) -> Content
}

public struct TransferBasketLoadingViewParameters {
    /// Name of the current retailer selected
    public let retailerName: String
    /// Open Retailer website to transfer the basket
    public let onAction: () -> Void

    public init(
        onAction: @escaping () -> Void,
        retailerName: String

    ) {
        self.onAction = onAction
        self.retailerName = retailerName
    }
}
