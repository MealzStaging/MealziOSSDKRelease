//
//  File.swift
//
//
//  Created by Damien Walerowicz on 08/07/2024.
//

import Foundation
import SwiftUI

@available(iOS 14, *)
public protocol TransferBasketWebviewProtocol {
    associatedtype Content: View
    func content(params: TransferBasketWebviewParameters) -> Content
}

public struct TransferBasketWebviewParameters {
    /// URL of the retailer checkout with ingredients shared
    public let url: URL
    /// Dismiss the webview & stop the process
    public let onDismiss: () -> Void

    public init(
        url: URL,
        onDismiss: @escaping () -> Void
    ) {
        self.url = url
        self.onDismiss = onDismiss
    }
}
