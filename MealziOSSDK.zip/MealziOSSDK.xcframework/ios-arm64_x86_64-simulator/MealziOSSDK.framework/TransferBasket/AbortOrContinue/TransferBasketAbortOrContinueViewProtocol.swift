//
//  File.swift
//
//
//  Created by Damien Walerowicz on 08/07/2024.
//

import Foundation
import SwiftUI

@available(iOS 14, *)
public protocol TransferBasketAbortOrContinueViewProtocol {
    associatedtype Content: View
    func content(params: TransferBasketAbortOrContinueViewParameters) -> Content
}

public struct TransferBasketAbortOrContinueViewParameters {
    /// Name of the current retailer selected
    public let retailerName: String
    /// Continue the basket transfer, navigate back to the retailer
    public let onContinue: () -> Void
    /// Stop the basket transfer & stay on the app
    public let onAbort: () -> Void

    public init(
        onContinue: @escaping () -> Void,
        onAbort: @escaping () -> Void,
        retailerName: String

    ) {
        self.onContinue = onContinue
        self.onAbort = onAbort
        self.retailerName = retailerName
    }
}
